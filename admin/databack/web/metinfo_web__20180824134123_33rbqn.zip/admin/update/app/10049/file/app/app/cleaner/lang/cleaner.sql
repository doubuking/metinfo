INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_name',value='清理程序缓存',site='1',no_order='0',array='0',lang='cn',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_yw002',value='清理成功',site='1',no_order='0',array='0',lang='cn',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_yw003',value='清理失败',site='1',no_order='0',array='0',lang='cn',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_info',value='清理程序缓存文件，解决程序升级更新后因为缓存出现的各种问题。',site='1',no_order='0',array='0',lang='cn',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_yw001',value='清理缓存',site='1',no_order='0',array='0',lang='cn',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_name',value='Cleanup program cache',site='1',no_order='0',array='0',lang='en',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_yw001',value='Clear cache',site='1',no_order='0',array='0',lang='en',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_yw002',value='Clean up success',site='1',no_order='0',array='0',lang='en',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_yw003',value='Cleanup failed',site='1',no_order='0',array='0',lang='en',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_info',value='Clean up the program cache files, to solve the problem after the upgrade because the cache cache.',site='1',no_order='0',array='0',lang='en',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_yw003',value='清理失敗',site='1',no_order='0',array='0',lang='tc',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_yw002',value='清理成功',site='1',no_order='0',array='0',lang='tc',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_yw001',value='清理緩存',site='1',no_order='0',array='0',lang='tc',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_info',value='清理程式緩存檔案，解决程式陞級更新後因為緩存出現的各種問題。',site='1',no_order='0',array='0',lang='tc',app = '{$this->no}' #;#;
INSERT INTO {$_M['config']['tablepre']}language SET name='cleaner_name',value='清理程式緩存',site='1',no_order='0',array='0',lang='tc',app = '{$this->no}' 