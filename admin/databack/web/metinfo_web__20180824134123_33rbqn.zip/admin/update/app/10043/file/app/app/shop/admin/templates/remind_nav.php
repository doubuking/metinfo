<?php
# MetInfo Enterprise Content Management System
# Copyright (C) MetInfo Co.,Ltd (https://www.metinfo.cn). All rights reserved.
defined('IN_MET') or exit('No permission');
?>
<ul class="nav nav-tabs nav-tabs-line">
	<li class='nav-item'><a class="nav-link {$remind_nav[1]}" href="{$_M['url']['own_form']}a=doremind_user">{$word.app_shop_remind_userremind}</a></li>
	<li class='nav-item'><a class="nav-link {$remind_nav[2]}" href="{$_M['url']['own_form']}a=doremind_admin">{$word.app_shop_remind_adminremind}</a></li>
</ul>