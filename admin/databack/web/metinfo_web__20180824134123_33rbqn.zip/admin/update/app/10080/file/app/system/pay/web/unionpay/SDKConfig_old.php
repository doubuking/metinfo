<?php
const MERID_CONFIG = '802440357320524';
const SDK_SIGN_CERT_PWD = '888666';
const SDK_LOG_LEVEL = PhpLog::OFF;
const SDK_SIGN_CERT_PATH = 'D:/phpStudy/WWW/met6/upload/file/1520577638.pfx';
const SDK_ENCRYPT_CERT_PATH = 'D:/phpStudy/WWW/met6/upload/file/1520577688.cer';
const SDK_VERIFY_CERT_DIR = 'D:/phpStudy/WWW/met6/upload/file/';
const SDK_FILE_DOWN_PATH = 'D:/phpStudy/WWW/met6/app/system/web/pay/unionpay/file/';
const SDK_LOG_FILE_PATH = 'D:/phpStudy/WWW/met6/app/system/web/pay/unionpay/logs/';
const SDK_FRONT_NOTIFY_URL = 'http://met6.com/pay/return.php';
const SDK_BACK_NOTIFY_URL = 'http://met6.com/pay/notify.php';
const SDK_FRONT_TRANS_URL = 'https://gateway.95516.com/gateway/api/frontTransReq.do';
const SDK_BACK_TRANS_URL = 'https://gateway.95516.com/gateway/api/backTransReq.do';
const SDK_BATCH_TRANS_URL = 'https://gateway.95516.com/gateway/api/batchTrans.do';
const SDK_SINGLE_QUERY_URL = 'https://gateway.95516.com/gateway/api/queryTrans.do';
const SDK_FILE_QUERY_URL = 'https://gateway.95516.com:9080/';
const SDK_Card_Request_Url = 'https://gateway.95516.com/gateway/api/cardTransReq.do';
const SDK_App_Request_Url = 'https://gateway.95516.com/gateway/api/appTransReq.do';
const JF_SDK_FRONT_TRANS_URL = 'https://gateway.95516.com/jiaofei/api/frontTransReq.do';
const JF_SDK_BACK_TRANS_URL = 'https://gateway.95516.com/jiaofei/api/backTransReq.do';
const JF_SDK_SINGLE_QUERY_URL = 'https://gateway.95516.com/jiaofei/api/queryTrans.do';
const JF_SDK_CARD_TRANS_URL = 'https://gateway.95516.com/jiaofei/api/cardTransReq.do';
const JF_SDK_APP_TRANS_URL = 'https://gateway.95516.com/jiaofei/api/appTransReq.do';
?>