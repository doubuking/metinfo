<?php
define('M_NAME', 'website');
define('M_MODULE', 'web');
define('M_CLASS', 'website');
define('M_ACTION', 'doindex');
require_once '../../entrance.php';
?>