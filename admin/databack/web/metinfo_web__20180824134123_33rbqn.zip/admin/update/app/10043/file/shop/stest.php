<?php
header("Content-type:text/html;charset=utf-8");

?>
    <html>
    <form action="http://met6.1.com/shop/order.php?a=doorder_close" method="post">
        <label>ID</label>
        <input type="text" name="id" value="">
        <br>
        <label>reason</label>
        <input type="text" name="reason" value="">
        <br>
        <label>detail</label>
        <input type="text" name="detail" value="">
        <br>
        <label>XX</label>
        <input type="text" name="XX" value="">
        <br>
        <label>XXX</label>
        <input type="text" name="XXX" value="">
        <br>
        <input type="submit" value="Submit">
    </form>
    </html>

<?php

?>