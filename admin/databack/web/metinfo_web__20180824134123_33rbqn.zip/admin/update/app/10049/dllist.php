<?php
$dllist = Array
(
    0 => 'install.class.php',
    1 => 'dllist.php',
    2 => 'file/app/app/cleaner/admin/index.class.php',
    3 => 'file/app/app/cleaner/admin/templates/index.php',
    4 => 'file/app/app/cleaner/admin/templates/js/own.js',
    5 => 'file/app/app/cleaner/admin/uninstall.class.php',
    6 => 'file/app/app/cleaner/icon.png',
    7 => 'file/app/app/cleaner/lang/cleaner.sql',
);
?>