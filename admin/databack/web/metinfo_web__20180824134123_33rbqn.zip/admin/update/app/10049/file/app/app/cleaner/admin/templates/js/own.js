define(function (require, exports, module) {
    
    var common = require('common'); //加载公共函数文件（语言文字获取等）
    var langtxt = common.langtxt(); //获取语言文字

});
