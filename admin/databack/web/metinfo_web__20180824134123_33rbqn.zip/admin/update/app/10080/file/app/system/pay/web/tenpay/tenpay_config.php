<?php
$spname="";
$partner = "";                                  	//财付通商户号
$key = "";			//财付通密钥

$return_url = "http://*/payReturnUrl.php";			//显示支付结果页面,*替换成payReturnUrl.php所在路径
$notify_url = "http://*/payNotifyUrl.php";			//支付完成后的回调处理页面,*替换成payNotifyUrl.php所在路径
?>