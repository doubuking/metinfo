<?php
$dllist=array (
  0 => 'dllist.php',
  1 => 'install.class.php',
  2 => 'file/app/app/met_sms/admin/index.class.php',
  3 => 'file/app/app/met_sms/admin/install.class.php',
  4 => 'file/app/app/met_sms/admin/templates/finance.php',
  5 => 'file/app/app/met_sms/admin/templates/index.php',
  6 => 'file/app/app/met_sms/admin/templates/js/own.js',
  7 => 'file/app/app/met_sms/admin/templates/mass.php',
  8 => 'file/app/app/met_sms/admin/templates/recharge.php',
  9 => 'file/app/app/met_sms/admin/templates/set_sign.php',
  10 => 'file/app/app/met_sms/admin/templates/sms_log.php',
  11 => 'file/app/app/met_sms/admin/uninstall.class.php',
  12 => 'file/app/app/met_sms/icon.png',
  13 => 'file/app/app/met_sms/include/class/met_sms.class.php',
);
?>