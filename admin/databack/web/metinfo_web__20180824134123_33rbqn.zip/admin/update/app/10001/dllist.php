<?php
$dllist = array (
0 => 'dllist.php',
1 => 'file/app/app/website/admin/templates/index.php',
2 => 'file/app/app/website/admin/uninstall.class.php',
3 => 'file/app/app/website/admin/website.class.php',
4 => 'file/app/app/website/icon.png',
5 => 'file/app/app/website/plugin/plugin_website.class.php',
6 => 'file/app/app/website/plugin/website.php',
7 => 'install.class.php'
);
?>