<include file="sys_web/head"/>
<div class="page bg-pagebg1">
    <div class="container">
        <div class="page-content row">
            <div class="panel panel-default m-b-0">
                <div class='panel-body'>
                    <!--section start-->

                    <div class="page bg-pagebg1">
                        <div class="col-lg-2 col-md-2 text-xs-center">
                            <i class="icon wb-check-circle font-size-80 green-400" aria-hidden="true"></i>
                        </div>
                        <div class="col-lg-7 col-md-6">
                            <h1 class='text-xs-center text-md-left'>{$word.pay_paidok}</h1>
                            <a href="{$data.callback}" id="callback" hidden>callback</a>
                        </div>
                    </div>


                    <!--section end-->
                </div>
            </div>
        </div>
    </div>
</div>
<include file="sys_web/foot"/>