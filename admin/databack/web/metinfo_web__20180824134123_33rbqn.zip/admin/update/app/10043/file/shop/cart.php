<?php
# MetInfo Enterprise Content Management System 
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved. 
@define('M_NAME', 'shop');
@define('M_MODULE', 'web');
@define('M_CLASS', 'cart');
@define('M_ACTION', @$_GET['a']);
require_once '../app/system/entrance.php';
die();
# This program is an open source system, commercial use, please consciously to purchase commercial license.
# Copyright (C) MetInfo Co., Ltd. (http://www.metinfo.cn). All rights reserved.
?>